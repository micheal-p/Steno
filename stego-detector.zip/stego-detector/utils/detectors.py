import os
from stegano.lsb import reveal as lsb_reveal
from PIL import Image

SEPARATOR = "\n---\n"

def is_valid_image(filepath):
    try:
        with Image.open(filepath) as img:
            img.verify()
        return True
    except Exception:
        return False

def get_image_lsb_capacity(filepath):
    with Image.open(filepath) as img:
        w, h = img.size
        channels = len(img.getbands())  # 3 for RGB, 4 for RGBA
        return (w * h * channels) // 8  # bytes

def detect_image_lsb(filepath):
    if not is_valid_image(filepath):
        return {
            "detected": None,
            "status": "Uploaded file is not a valid or supported image.",
            "message": "",
            "messages_list": [],
            "capacity": 0,
            "used": 0,
            "remaining": 0
        }
    try:
        hidden_message = lsb_reveal(filepath)
        capacity = get_image_lsb_capacity(filepath)
        used = len(hidden_message.encode("utf-8")) if hidden_message else 0
        remaining = capacity - used
        if hidden_message is None:
            return {
                "detected": False,
                "status": "No hidden message detected. (File appears safe.)",
                "message": "",
                "messages_list": [],
                "capacity": capacity,
                "used": used,
                "remaining": remaining
            }
        else:
            messages_list = hidden_message.split(SEPARATOR)
            return {
                "detected": True,
                "status": "Steganography Detected (Image LSB)",
                "message": hidden_message,
                "messages_list": messages_list,
                "capacity": capacity,
                "used": used,
                "remaining": remaining
            }
    except Exception as e:
        return {
            "detected": None,
            "status": f"Error during image processing: {e}",
            "message": "",
            "messages_list": [],
            "capacity": 0,
            "used": 0,
            "remaining": 0
        }

def detect_image_ai(filepath):
    return {
        "detected": False,
        "status": "No Steganography Detected (AI Model)",
        "message": "",
        "messages_list": [],
        "capacity": 0,
        "used": 0,
        "remaining": 0
    }

def detect_audio(filepath):
    return {
        "detected": None,
        "status": "Audio steganography detection not implemented.",
        "message": "",
        "messages_list": [],
        "capacity": 0,
        "used": 0,
        "remaining": 0
    }

def detect_video(filepath):
    return {
        "detected": None,
        "status": "Video steganography detection not implemented.",
        "message": "",
        "messages_list": [],
        "capacity": 0,
        "used": 0,
        "remaining": 0
    }

def detect_steganography(filepath):
    ext = os.path.splitext(filepath)[1].lower()
    if ext in ['.png', '.bmp']:
        result = detect_image_lsb(filepath)
        if result["detected"]:
            return result
        ai_result = detect_image_ai(filepath)
        return ai_result if ai_result["detected"] else result
    elif ext in ['.jpg', '.jpeg']:
        return detect_image_ai(filepath)
    elif ext in ['.wav', '.mp3']:
        return detect_audio(filepath)
    elif ext in ['.mp4', '.avi', '.mov']:
        return detect_video(filepath)
    else:
        return {
            "detected": None,
            "status": "Unsupported file type for steganography detection.",
            "message": "",
            "messages_list": [],
            "capacity": 0,
            "used": 0,
            "remaining": 0
        }