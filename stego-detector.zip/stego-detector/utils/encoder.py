from stegano.lsb import reveal, hide
from PIL import Image
from io import BytesIO

SEPARATOR = "\n---\n"  # Unique separator for messages

def encode_message_lsb(image_path, new_message):
    try:
        # Validate image
        with Image.open(image_path) as img:
            img.verify()
        # Get current hidden message(s), if any
        try:
            current = reveal(image_path)
        except Exception:
            current = None
        if current and current.strip():
            combined = f"{current}{SEPARATOR}{new_message}"
        else:
            combined = new_message
        # Hide the combined message(s)
        stego = hide(image_path, combined)
        stego_bytes = BytesIO()
        stego.save(stego_bytes, format='PNG')
        stego_bytes.seek(0)
        return stego_bytes, None
    except Exception as e:
        return None, f"Failed to encode message: {e}"