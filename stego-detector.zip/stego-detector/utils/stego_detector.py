import pickle
import numpy as np
import os

MODEL_PATH = os.path.join('models', 'stego_rf.pkl')
ENCODER_PATH = os.path.join('models', 'file_type_encoder.pkl')

with open(MODEL_PATH, 'rb') as f:
    clf = pickle.load(f)
with open(ENCODER_PATH, 'rb') as f:
    file_type_encoder = pickle.load(f)

def detect_steganography_from_features(features_dict):
    file_type = file_type_encoder.transform([features_dict['file_type']])[0]
    X = np.array([[
        file_type,
        features_dict['file_size_kb'],
        features_dict['hidden_msg_size_b'],
        features_dict['entropy'],
        features_dict['lsb_uniformity'],
        features_dict['red_mean'],
        features_dict['green_mean'],
        features_dict['blue_mean'],
        features_dict['chi_square_result']
    ]])
    pred = clf.predict(X)[0]
    proba = clf.predict_proba(X)[0][1]  # Probability of positive class
    status = "Steganography Detected" if pred == 1 else "No Steganography Detected"
    return {
        'status': status,
        'confidence': float(proba),
        'details': f"Model prediction probability: {proba:.2f}"
    }