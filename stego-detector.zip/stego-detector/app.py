import os
from flask import Flask, render_template, request, redirect, url_for, flash, send_from_directory
from werkzeug.utils import secure_filename
from utils.detectors import detect_steganography
from utils.encoder import encode_message_lsb  # For the encoder page
from io import BytesIO

UPLOAD_FOLDER = 'uploads'
ENCODED_FOLDER = os.path.join(UPLOAD_FOLDER, 'encoded')
ALLOWED_EXTENSIONS = {'.png', '.jpg', '.jpeg', '.bmp', '.wav', '.mp3', '.mp4', '.avi', '.mov'}

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.secret_key = 'supersecretkey'

# Ensure folders exist
for folder in [UPLOAD_FOLDER, ENCODED_FOLDER]:
    os.makedirs(folder, exist_ok=True)

def allowed_file(filename):
    ext = os.path.splitext(filename)[1].lower()
    return ext in ALLOWED_EXTENSIONS

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        if 'file' not in request.files:
            flash('No file part')
            return redirect(request.url)
        file = request.files['file']
        if file.filename == '':
            flash('No selected file')
            return redirect(request.url)
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(filepath)
            result = detect_steganography(filepath)
            return render_template('result.html', filename=filename, result=result)
        else:
            flash('File type not allowed')
            return redirect(request.url)
    return render_template('index.html')

@app.route('/uploads/<filename>')
def uploaded_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

@app.route('/encode', methods=['GET', 'POST'])
def encode():
    if request.method == 'POST':
        if 'file' not in request.files or request.files['file'].filename == '':
            flash('No image file selected')
            return redirect(request.url)
        file = request.files['file']
        secret = request.form.get('secret', '')
        if file and allowed_file(file.filename) and file.filename.lower().endswith(('.png', '.bmp')):
            filename = secure_filename(file.filename)
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(filepath)
            # Encode message
            stego_img_bytes, error = encode_message_lsb(filepath, secret)
            if error:
                flash(error)
                return redirect(request.url)
            stego_filename = f"stego_{filename}"
            stego_path = os.path.join(ENCODED_FOLDER, stego_filename)
            with open(stego_path, 'wb') as f:
                f.write(stego_img_bytes.getbuffer())
            return render_template('encode_result.html', stego_filename=stego_filename)
        else:
            flash('Only PNG or BMP images are supported for encoding.')
            return redirect(request.url)
    return render_template('encode.html')

@app.route('/download/<stego_filename>')
def download_stego(stego_filename):
    return send_from_directory(ENCODED_FOLDER, stego_filename, as_attachment=True)

if __name__ == '__main__':
    app.run(debug=True)