import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import LabelEncoder
import pickle
import os

# 1. Try loading with comma, then tab if needed
try:
    df = pd.read_csv('data/stego.csv', sep=',')
    if len(df.columns) == 1:
        df = pd.read_csv('data/stego.csv', sep='\t')
except Exception as e:
    print("Error loading CSV:", e)
    raise

df.columns = df.columns.str.strip()  # Remove spaces

print("Loaded columns:", df.columns.tolist())

# 2. Simulate label (replace with real labels if you have them!)
import numpy as np
np.random.seed(42)
df['has_hidden_msg'] = np.random.randint(0, 2, len(df))

# 3. Encode 'file_type'
le = LabelEncoder()
df['file_type_encoded'] = le.fit_transform(df['file_type'])

# 4. Features
features = [
    'file_type_encoded','file_size_kb','hidden_msg_size_b','entropy','lsb_uniformity',
    'red_mean','green_mean','blue_mean','chi_square_result'
]
X = df[features]
y = df['has_hidden_msg']

# 5. Split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# 6. Train
clf = RandomForestClassifier(n_estimators=100, random_state=42)
clf.fit(X_train, y_train)

# 7. Score
print(f"Test accuracy: {clf.score(X_test, y_test):.2f}")

# 8. Save model and encoder
os.makedirs('models', exist_ok=True)
with open('models/stego_rf.pkl', 'wb') as f:
    pickle.dump(clf, f)
with open('models/file_type_encoder.pkl', 'wb') as f:
    pickle.dump(le, f)